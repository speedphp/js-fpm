# A FastCGI Process Manager for NodeJS

## TODO LIST

- 服务存在文件的输出
- include包含文件如何处理？
- jhtml文件的支持优化
- webapps配置支持
- 测试浏览型小网站
- cookie、session
- header
- sqlite
- in.post，get，upload，query
- out.write，end，redirect
- util.html_escape，file_get，file_put
- 文档
- demo
- 发布

## Architecture

cookie

session

header

sqlite

in
- post
- get
- upload
- query
	
out
- write
- end
- redirect

util
- html_escape
- file_get
- file_put
	